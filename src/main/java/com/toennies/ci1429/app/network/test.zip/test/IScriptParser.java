package com.toennies.ci1429.app.network.test;

import java.io.InputStream;

public interface IScriptParser
{
	 Script parse(InputStream inputStream);
}
