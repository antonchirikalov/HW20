package com.toennies.ci1429.app.network.test;


import java.io.IOException;

public interface IScriptCommand
{
	void execute() throws IOException;
}
