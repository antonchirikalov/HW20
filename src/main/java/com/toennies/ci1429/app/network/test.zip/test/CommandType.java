package com.toennies.ci1429.app.network.test;

public enum CommandType
{
	SEND, RECEIVE, WAIT, ACTIVATE, DEACTIVATE
}
